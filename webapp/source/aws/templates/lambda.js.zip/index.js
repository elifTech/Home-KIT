'use strict'
var AWS=require('aws-sdk');
exports.handler = (event, context, callback) => {

    callback(AWS, event);

};